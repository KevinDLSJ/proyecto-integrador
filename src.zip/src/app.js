const express = require('express');
const { engine } = require('express-handlebars');
const myconnection = require('express-myconnection');
const mysql = require('mysql');
const session = require('express-session');
const bodyParser = require('body-parser')
const principalController = require('./routes/adm_tick');

const app = express();
app.set('port', process.env.PORT || 8000);

app.set('views', __dirname + '/views');
app.engine('.hbs', engine({
	extname: '.hbs',
}));
app.set('view engine', '.hbs');

app.use(bodyParser.urlencoded({ 
	extended: true 
}));
app.use(bodyParser.json());	

app.use(myconnection(mysql, {
	host: 'localhost',
	user: 'root',
	password: '',
	port: 3307,
	database: 'bdabarrotes'
}));

app.listen(app.get('port'), () => {
	console.log('listening on port ', app.get('port'));
});

app.use('/', principalController);

app.get('/', (req, res) => {
	res.render('home');
});
function ticket(req, res){
    res.render('main/ticket_main');
}



module.exports = {
  ticket: ticket,
}
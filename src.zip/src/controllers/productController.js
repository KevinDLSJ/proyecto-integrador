function product(req, res) {
    res.render('main/prod/product');
}

module.exports = {
    product: product,
}
function admin(req, res) {
    req.getConnection((err, conn) =>{
        conn.query('SELECT * FROM proveedor', (err, proveedores) => {
            if(err){
                res.json(err);
                console.log(err);
            }
            console.log(proveedores);
            res.render('main/admin_main', {proveedores: proveedores});

        })
    })
  
}

function buscarReal(req, res) {
  const texto = req.query.texto || '';
  const buscar = `%${texto}%`;

  req.getConnection((err, conn) => {
    if (err) return res.status(500).json({ error: 'Error de conexión' });

    conn.query(
      'SELECT * FROM proveedor WHERE nombre LIKE ? OR contacto LIKE ? OR telefono LIKE ? LIMIT 10',
      [buscar, buscar, buscar],
      (err, resultados) => {
        if (err) return res.status(500).json({ error: 'Error en consulta' });

        res.json(resultados);
      }
    );
  });
}

function newprov(req, res) {
  const data = {
    nombre: req.body.nombre,
    contacto: req.body.contacto,
    telefono: req.body.telefono,
    direccion: req.body.direccion,
    fecha_registro: req.body.fecha_registro,
    email: req.body.email,
  };

  console.log('Datos recibidos:', data); // 👈 Verifica qué llega del form

  req.getConnection((err, conn) => {
    if (err) {
      console.error('Error de conexión:', err);
      return res.status(500).send('Error de conexión');
    }

    conn.query('INSERT INTO proveedor SET ?', data, (err, resultados) => {
      if (err) {
        console.error('Error al guardar proveedor:', err); // 👈 Ver error real
        return res.status(500).send('Error al guardar');
      }
      console.log('Proveedor agregado:', resultados);
      res.redirect('/admin');
    });
  });
}

/*function prov_edit(req, res) {
  const id = req.query.id;

  req.getConnection((err, conn) => {
    if (err) {
      console.error('Error de conexión:', err);
      return res.status(500).send('Error de conexión');
    }

    conn.query(
      'UPDATE proveedor SET ? WHERE proveedor_id = ?',
      [req.body, id],
      (err, resultados) => {
        if (err) {
          console.error('Error al actualizar proveedor:', err);
          return res.status(500).send('Error al actualizar proveedor');
        }
        console.log('Proveedor actualizado:', resultados);
        res.redirect('/admin');
      }
    );
  });
}*/

function provnew(req, res) {
  res.render('main/admin/prov_new');

}

/*function editar(req, res) {
  res.render('main/admin/prov_edit', {proveedor: req.body});

}*/


module.exports = {
    admin: admin,
    buscarReal: buscarReal,
    provnew: provnew,
    newprov : newprov,
    //editar,
    //prov_edit,
}
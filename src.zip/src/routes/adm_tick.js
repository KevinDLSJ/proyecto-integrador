const express = require('express');
const principalController = require('../controllers/principalController');
const adminController = require('../controllers/adminController');
const productController = require('../controllers/productController');

const router = express.Router();

router.get('/ticket_main', principalController.ticket);

router.get('/admin', adminController.admin);
router.get('/buscar', adminController.buscarReal);
router.get('/prov_new', adminController.provnew);
router.post('/prov_new', adminController.newprov);
//router.get('/prov_edit', adminController.editar);

//router.get('/product', productController.product);


module.exports = router;